


function Error(){

    return (
        <div>
            <h1>Pagina no encontrada 404</h1>
        </div>
    )
}

export default Error;