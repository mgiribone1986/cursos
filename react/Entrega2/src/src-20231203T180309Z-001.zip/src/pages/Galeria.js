import { Link } from "react-router-dom";

function Galeria(){

    return (
        <div>
            <h1>Bienvenido/a a Galeria</h1>
            <Link to="/">Home</Link>
        </div>
    )
}

export default Galeria;