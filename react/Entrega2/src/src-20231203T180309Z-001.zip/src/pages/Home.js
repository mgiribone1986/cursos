
function Home(){

    return (
        <div>
           <h1>Bienvenido/a Home</h1>            
        </div>
    )
}

export default Home;